import NavigationBar from './components/NavigationBar';
import LogoHeader from './components/LogoHeader';
import HeroBanner from './components/HeroBanner';
import AboutSection from './components/AboutSection';
import MissionVisionSection from './components/MissionVisionSection';
import ObjectivesSection from './components/ObjectivesSection';
import ActionLinesSection from './components/ActionLinesSection';
import ProjectsSection from './components/ProjectsSection';
import AlliancesSection from './components/AlliancesSection';
import ContactSection from './components/ContactSection';
import LeadershipSection from './components/LeadershipSection';
import Footer from './components/Footer';

const App = () => {
  return (
    <div className="font-sans">
      <NavigationBar />
      <div id="inicio">
        <LogoHeader />
        <HeroBanner />
      </div>
      <div id="quienes-somos">
        <AboutSection />
      </div>
      <div id="mision-vision">
        <MissionVisionSection />
      </div>
      <div id="objetivos">
        <ObjectivesSection />
      </div>
      <div id="lineas-accion">
        <ActionLinesSection />
      </div>
      <div id="proyectos">
        <ProjectsSection />
      </div>
      <div id="alianzas">
        <AlliancesSection />
      </div>
      <div id="contacto">
        <ContactSection />
      </div>
      <LeadershipSection />
      <Footer />
    </div>
  );
};

export default App;

// DONE