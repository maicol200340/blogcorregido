const LogoHeader = () => {
  return (
    <div className="flex justify-center py-8">
      <div className="w-40 h-40 rounded-full bg-white shadow-lg flex items-center justify-center overflow-hidden">
        <img 
          src="https://4tsix0yujj.ufs.sh/f/2vMRHqOYUHc048wL8C007fmwyReAgKCraUIWzEDZ6on58JNO" 
          alt="Logo Fundación JLC" 
          className="w-full h-full object-contain p-4"
        />
      </div>
    </div>
  );
};

export default LogoHeader;