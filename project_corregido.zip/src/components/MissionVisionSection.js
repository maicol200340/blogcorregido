const MissionVisionSection = () => {
  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Misión */}
          <div className="bg-white p-8 rounded-xl shadow-md border-l-4 border-green-600">
            <h3 className="text-2xl font-bold mb-4 text-green-800">Misión</h3>
            <p className="text-gray-700">
              Impulsar el desarrollo educativo, científico y tecnológico de las comunidades, mediante 
              la creación, promoción y ejecución de proyectos sostenibles que fortalezcan las capacidades 
              individuales y colectivas, fomentando la equidad y la innovación.
            </p>
          </div>

          {/* Visión */}
          <div className="bg-white p-8 rounded-xl shadow-md border-l-4 border-blue-600">
            <h3 className="text-2xl font-bold mb-4 text-blue-800">Visión</h3>
            <p className="text-gray-700">
              Para el año 2030, la Fundación JLC será una organización reconocida a nivel nacional por su 
              capacidad de liderar procesos de transformación social mediante el uso estratégico de la ciencia, 
              la tecnología, la educación y la sostenibilidad ambiental.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MissionVisionSection;