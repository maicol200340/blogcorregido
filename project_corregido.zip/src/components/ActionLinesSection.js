const ActionLinesSection = () => {
  const actionLines = [
    {
      title: "Tecnología y desarrollo digital",
      description: "Implementación de software, desarrollo de apps, plataformas digitales y animaciones educativas.",
      icon: "💻"
    },
    {
      title: "Educación y formación",
      description: "Formación técnica y tecnológica, cursos para el trabajo y el desarrollo humano, talleres, seminarios.",
      icon: "📚"
    },
    {
      title: "Proyectos científicos",
      description: "Investigación aplicada, participación en redes de innovación y convocatorias nacionales e internacionales.",
      icon: "🔬"
    },
    {
      title: "Sostenibilidad",
      description: "Actividades de educación ambiental, conservación de la biodiversidad y proyectos comunitarios sostenibles.",
      icon: "🌱"
    },
    {
      title: "Intervención social",
      description: "Desarrollo de procesos sociales, culturales y comunitarios que buscan la transformación del entorno.",
      icon: "🤝"
    }
  ];

  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12 text-green-800">Líneas de Acción</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {actionLines.map((line, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">{line.icon}</div>
              <h3 className="text-xl font-bold mb-2 text-green-700">{line.title}</h3>
              <p className="text-gray-600">{line.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ActionLinesSection;