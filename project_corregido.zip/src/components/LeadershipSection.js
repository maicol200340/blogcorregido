const LeadershipSection = () => {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-10 text-green-800">Nuestro Equipo</h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-gray-50 p-6 rounded-lg shadow-sm text-center">
            <div className="h-32 w-32 rounded-full bg-green-200 mx-auto mb-4 flex items-center justify-center text-5xl text-green-800">
              ÓC
            </div>
            <h3 className="text-xl font-semibold mb-2">Óscar Conde Ortiz</h3>
            <p className="text-green-700 font-medium">Presidente</p>
          </div>
          
          <div className="bg-gray-50 p-6 rounded-lg shadow-sm text-center">
            <div className="h-32 w-32 rounded-full bg-green-200 mx-auto mb-4 flex items-center justify-center text-5xl text-green-800">
              AA
            </div>
            <h3 className="text-xl font-semibold mb-2">Aracelis Andrade Prada</h3>
            <p className="text-green-700 font-medium">Vicepresidenta</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LeadershipSection;